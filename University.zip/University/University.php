<?php
require_once "AbstractUniversity.php";

/**
 * Class University
 */
class University extends AbstractUniversity
{
    // TODO Implement all the methods declared in parent
    public function addSubject(string $code, string $name): Subject
    {
        if ($this->cs($code,$name)){
            $subj=new Subject($code,$name);
            $this->subjects[]=$subj;
            return $subj;
        }
        else {
            throw new Exception("Hiba");
        }
        // TODO: Implement addSubject() method.
    }

    public function addStudentOnSubject(string $subjectCode, Student $student)
    {
        foreach($this->subjects as $s){
            if($s->getCode() == $subjectCode ){
                return $s->addStudent($student->getName(), $student->getStuNum());
            }
        }
    }

    public function getStudentsForSubject(string $subjectCode)
    {
        foreach ($this->subjects as $s){
            if ($s->getCode()==$subjectCode){
                return $s->getStudents();

            }
            return [];
        }
        // TODO: Implement getStudentsForSubject() method.
    }

    public function getNumberOfStudents(): int
    {
        $ossz=0;
        foreach($this->subjects as $std){
            foreach($std->getStudents() as $st){
                $ossz++;
            }
        }
        return "Students number: ". std."\n";


        // TODO: Implement getNumberOfStudents() method.
    }

    public function print()
    {
        foreach($this->subjects as $s){
            echo $s->getCode().$s->getName();
            foreach($s->getStudents() as $s){
                echo $s->getName().$s->getStudentNumber();

            }

        }
        // TODO: Implement print() method.
    }



















    public function cs(string $code, string $name){

        if(count($this->subjects) == 0) return true;
        foreach($this->subjects as $item){

            if ($item->getCode() == $code && $item->getName() == $name){
                return false;
            }
        }
        return true;
    }
}