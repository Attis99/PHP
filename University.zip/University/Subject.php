<?php
/**
 * User: TheCodeholic
 * Date: 4/8/2020
 * Time: 10:16 PM
 */

/**
 * Class Subject
 */
class Subject
{
    public $code;
    public $name;
    /**
     * @var Student[]
     */
    public $students = [] ;

    // TODO Generate getters and setters
    // TODO Generate constructor for all attributes. $students argument of the constructor can be empty
    public function __construct(string $code, string $name, array $students = [] ){

        $this->code = $code;
        $this->name =$name;
        $this->students=$students;

    }

    /**
     * @return string
     */
    public function getCode(): string
    {
        return $this->code;
    }

    /**
     * @param string $code
     */
    public function setCode(string $code): void
    {
        $this->code = $code;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @return array|Student[]
     */
    public function getStudents(): array
    {
        return $this->students;
    }


    /**
     * Method accepts student name and number, creates instance of the Student class, adds inside $students array
     * and returns created instance
     *
     * @param string $name
     * @param string $studentNumber
     * @return \Student
     */
    public function addStudent(string $name, string $studentNumber): Student
    {
        if ($this->existStudent()){


        //TODO Implement method according to method annotation
        $student = new Student($name,$studentNumber);
        $this->students[] = $student;
        return $student."Beteve";}
        else {
            throw new Exception();
        }

    }


    public function existControl($studentNumber){

        if(count($this->students) == 0) return true;
        foreach($this->students as $stu){
            if ($stu->getStuNum() == $studentNumber){
                return false;
            }
        }
        return true;
    }

    public function __toString():string
    {
        return $this->getCode()." ".$this->getName();
        // TODO: Implement __toString() method.
    }


}